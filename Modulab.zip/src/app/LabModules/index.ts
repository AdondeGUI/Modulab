// module
export * from './LabModules.module';