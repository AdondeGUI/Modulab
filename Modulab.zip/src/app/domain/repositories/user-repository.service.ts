import { Injectable } from "@angular/core";
import { User } from './../models/user';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable()
export class UserRepository {
    protected endpoint = 'http://52.15.171.47/';
    
    constructor(
        protected http: HttpClient,
    ) {}

    // public getUser(attempt: string) {
    //     this.http.get('http://52.15.171.47/login/'+attempt).subscribe(data => {
    //       this.userManager.user = data[0];
    //       this.router.navigateByUrl('/directory');
    //     });
    // }

    public getUser(attempt: string): Observable<User[]> {
        return this.http.get<User[]>('http://52.15.171.47/login/'+attempt)
        .catch(x => this.handleException(x));
    }

    protected handleException(exception: any) {
        var message = `${exception.status} : ${exception.statusText}\r\n${exception.body.error}`;
        alert(message);
        return Observable.throw(message);
    }
}
