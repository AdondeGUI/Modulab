import { Injectable } from "@angular/core";
import { Lab } from './../models/lab';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";
import { UserManager } from "../../user-manager.service"

@Injectable()
export class LabRepository {
    protected endpoint = 'api/products';
    
    constructor(
        protected http: HttpClient,
        private userManager: UserManager
    ) {}

      //get all labs for a particular user
    public getLabs() {
        this.http.get('http://52.15.171.47/users/'+ this.userManager.user.id +'/labs').subscribe(data => {
        console.log(data);
        });
    }

}
