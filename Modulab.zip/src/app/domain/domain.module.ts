import { NgModule } from '@angular/core';
import{ BrowserModule } from '@angular/platform-browser';
import{ TextData } from './models/text-data';
import { UserRepository } from './repositories/user-repository.service'


@NgModule({
    imports: [BrowserModule],
    declarations:[TextData],
    exports:[TextData],
    providers:[UserRepository]
})

export class DomainModule{

}