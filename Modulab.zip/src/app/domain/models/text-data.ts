export class TextData{
    type?: string;
    desc?: string;
}
