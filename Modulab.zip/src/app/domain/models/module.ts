export class Module{
    type?: string;
    data?: {};
    module_id?: number;
    lab_id?: number;
}
