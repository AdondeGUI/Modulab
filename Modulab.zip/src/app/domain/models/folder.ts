export class Folder{
    files?: string[];
}