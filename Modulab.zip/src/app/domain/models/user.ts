export class User{
    email?: string;
    first_name?: string;
    last_name?: string;
    password?: string;
    role?: number;
    ID?: number;
}