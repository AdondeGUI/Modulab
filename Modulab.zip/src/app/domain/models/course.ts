export class Course{
    ID?: number;
    course_id?: number;
    title?: String;
    instructor?: String;
}