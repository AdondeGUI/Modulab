export class Course{
    ID?: number;
    title?: string;
    instructor?: string;
    course_id?: number;
}