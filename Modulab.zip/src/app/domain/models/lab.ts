import{ Module } from './Module';
import{ User } from './User';

export class Lab{
    id?: number;
    course_id?: number;
    lab_id?: number;
    title?: string;
}
